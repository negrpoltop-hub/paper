package com.adminmod.paper;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.concurrent.ThreadLocalRandom;

/** Запускает несколько падающих "метеоритов" вокруг точки, куда смотрит игрок, с огненным взрывом при падении. */
public final class MeteorTask {

    private static final int METEOR_COUNT = 10;
    private static final int RADIUS = 8;
    private static final int SPAWN_HEIGHT = 20;
    private static final int INTERVAL_TICKS = 4;

    private MeteorTask() {
    }

    public static void start(AdminModPlugin plugin, Player player) {
        Location center = AdminModPlugin.lookTargetStatic(player, 50);
        player.sendMessage("§cМетеоритный дождь начался.");
        new BukkitRunnable() {
            int launched = 0;

            @Override
            public void run() {
                if (launched >= METEOR_COUNT) {
                    cancel();
                    return;
                }
                launchOne(plugin, center);
                launched++;
            }
        }.runTaskTimer(plugin, 0L, INTERVAL_TICKS);
    }

    private static void launchOne(AdminModPlugin plugin, Location center) {
        ThreadLocalRandom random = ThreadLocalRandom.current();
        double x = center.getX() + (random.nextDouble() * 2 - 1) * RADIUS;
        double z = center.getZ() + (random.nextDouble() * 2 - 1) * RADIUS;
        Location spawnLoc = new Location(center.getWorld(), x, center.getY() + SPAWN_HEIGHT, z);

        FallingBlock meteor = center.getWorld().spawnFallingBlock(spawnLoc, Material.MAGMA_BLOCK.createBlockData());
        meteor.setDropItem(false);
        meteor.setHurtEntities(true);

        new BukkitRunnable() {
            int age = 0;

            @Override
            public void run() {
                age++;
                if (meteor.isDead() || !meteor.isValid() || age > 200) {
                    if (!meteor.isDead()) {
                        meteor.remove();
                    }
                    Location explodeAt = meteor.getLocation();
                    explodeAt.getWorld().createExplosion(explodeAt, 2.5f, true, true);
                    cancel();
                    return;
                }
                if (meteor.isOnGround()) {
                    Location explodeAt = meteor.getLocation();
                    meteor.remove();
                    explodeAt.getWorld().createExplosion(explodeAt, 2.5f, true, true);
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }
}
