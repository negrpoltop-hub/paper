package com.adminmod.paper;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Objects;

/**
 * AdminMod для Paper. Все команды требуют право adminmod.use (по умолчанию — оператор).
 * Плагин ставится только на сервер, клиенту ничего ставить не нужно.
 */
public class AdminModPlugin extends JavaPlugin implements CommandExecutor, Listener {

    public static final String PANEL_TITLE = ChatColor.DARK_RED + "Админ-панель";
    private static final String BOMB_NAME = ChatColor.RED + "Жезл бомб";

    @Override
    public void onEnable() {
        for (String cmd : List.of("admin", "enchantmax", "repair", "heal", "feed", "fly", "god",
                "nightvision", "speed", "cleareffects", "smite", "clearmobs", "meteor", "bombwand")) {
            Objects.requireNonNull(getCommand(cmd)).setExecutor(this);
        }
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("AdminMod (Paper) загружен");
    }

    // ---------- команды ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Эта команда доступна только игрокам.");
            return true;
        }
        switch (command.getName()) {
            case "admin" -> openPanel(player);
            case "enchantmax" -> enchantMax(player, args.length > 0 ? parseLevel(args[0]) : 0);
            case "repair" -> repair(player);
            case "heal" -> heal(player);
            case "feed" -> feed(player);
            case "fly" -> toggleFly(player);
            case "god" -> toggleGod(player);
            case "nightvision" -> toggleInfinite(player, PotionEffectType.NIGHT_VISION, "Ночное зрение");
            case "speed" -> toggleInfinite(player, PotionEffectType.SPEED, "Ускорение");
            case "cleareffects" -> clearEffects(player);
            case "smite" -> smite(player);
            case "clearmobs" -> clearMobs(player);
            case "meteor" -> MeteorTask.start(this, player);
            case "bombwand" -> giveBombWand(player);
            default -> { return false; }
        }
        return true;
    }

    private int parseLevel(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ---------- панель ----------

    private void openPanel(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, PANEL_TITLE);
        inv.setItem(10, icon(Material.ENCHANTED_BOOK, "Зачаровать максимум"));
        inv.setItem(11, icon(Material.ANVIL, "Починить предмет"));
        inv.setItem(12, icon(Material.GOLDEN_APPLE, "Лечение + сытость"));
        inv.setItem(13, icon(Material.FEATHER, "Полёт"));
        inv.setItem(14, icon(Material.TOTEM_OF_UNDYING, "Неуязвимость"));
        inv.setItem(15, icon(Material.ENDER_EYE, "Ночное зрение"));
        inv.setItem(16, icon(Material.SUGAR, "Ускорение"));
        inv.setItem(19, icon(Material.MILK_BUCKET, "Снять эффекты"));
        inv.setItem(20, icon(Material.LIGHTNING_ROD, "Молния в прицел"));
        inv.setItem(21, icon(Material.DIAMOND_SWORD, "Убрать мобов рядом"));
        inv.setItem(22, icon(Material.FIRE_CHARGE, "Метеоритный дождь"));
        inv.setItem(23, icon(Material.BLAZE_ROD, "Выдать жезл бомб"));
        player.openInventory(inv);
    }

    private ItemStack icon(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + name);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onPanelClick(InventoryClickEvent event) {
        if (!PANEL_TITLE.equals(event.getView().getTitle())) {
            return;
        }
        event.setCancelled(true);
        if (!(event.getWhoClicked() instanceof Player player) || event.getCurrentItem() == null) {
            return;
        }
        if (!player.hasPermission("adminmod.use")) {
            return;
        }
        switch (event.getSlot()) {
            case 10 -> enchantMax(player, 0);
            case 11 -> repair(player);
            case 12 -> heal(player);
            case 13 -> toggleFly(player);
            case 14 -> toggleGod(player);
            case 15 -> toggleInfinite(player, PotionEffectType.NIGHT_VISION, "Ночное зрение");
            case 16 -> toggleInfinite(player, PotionEffectType.SPEED, "Ускорение");
            case 19 -> clearEffects(player);
            case 20 -> smite(player);
            case 21 -> clearMobs(player);
            case 22 -> MeteorTask.start(this, player);
            case 23 -> giveBombWand(player);
            default -> { }
        }
    }

    // ---------- действия ----------

    private void enchantMax(Player player, int forcedLevel) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() == Material.AIR) {
            player.sendMessage(ChatColor.RED + "Возьмите предмет в руку.");
            return;
        }
        ItemMeta meta = item.getItemMeta();
        for (Enchantment ench : Registry.ENCHANTMENT) {
            if (!ench.canEnchantItem(item)) {
                continue;
            }
            int level = forcedLevel > 0 ? forcedLevel : ench.getMaxLevel();
            meta.addEnchant(ench, level, true);
        }
        item.setItemMeta(meta);
        player.sendMessage(ChatColor.GREEN + "Предмет зачарован на максимум.");
    }

    private void repair(Player player) {
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getItemMeta() instanceof Damageable damageable) {
            damageable.setDamage(0);
            item.setItemMeta((ItemMeta) damageable);
            player.sendMessage(ChatColor.GREEN + "Предмет починен.");
        } else {
            player.sendMessage(ChatColor.RED + "Этот предмет нельзя починить.");
        }
    }

    private void heal(Player player) {
        var maxAttr = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH);
        player.setHealth(maxAttr != null ? maxAttr.getValue() : 20.0);
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.sendMessage(ChatColor.GREEN + "Здоровье и голод восстановлены.");
    }

    private void feed(Player player) {
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.sendMessage(ChatColor.GREEN + "Голод восстановлен.");
    }

    private void toggleFly(Player player) {
        boolean next = !player.getAllowFlight();
        player.setAllowFlight(next);
        player.setFlying(next);
        player.sendMessage(ChatColor.GREEN + "Полёт: " + (next ? "включён" : "выключен"));
    }

    private void toggleGod(Player player) {
        boolean next = !player.isInvulnerable();
        player.setInvulnerable(next);
        player.sendMessage(ChatColor.GREEN + "Неуязвимость: " + (next ? "включена" : "выключена"));
    }

    private void toggleInfinite(Player player, PotionEffectType type, String name) {
        if (player.hasPotionEffect(type)) {
            player.removePotionEffect(type);
            player.sendMessage(ChatColor.GREEN + name + ": выключено");
        } else {
            player.addPotionEffect(new PotionEffect(type, Integer.MAX_VALUE, 1, true, false));
            player.sendMessage(ChatColor.GREEN + name + ": включено");
        }
    }

    private void clearEffects(Player player) {
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
        player.sendMessage(ChatColor.GREEN + "Все эффекты сняты.");
    }

    private void smite(Player player) {
        Location target = lookTarget(player, 60);
        player.getWorld().strikeLightning(target);
    }

    private void clearMobs(Player player) {
        int removed = 0;
        for (Entity entity : player.getNearbyEntities(24, 24, 24)) {
            if (entity instanceof Monster) {
                entity.remove();
                removed++;
            }
        }
        player.sendMessage(ChatColor.GREEN + "Убрано мобов: " + removed);
    }

    private void giveBombWand(Player player) {
        ItemStack wand = new ItemStack(Material.BLAZE_ROD);
        ItemMeta meta = wand.getItemMeta();
        meta.setDisplayName(BOMB_NAME);
        wand.setItemMeta(meta);
        player.getInventory().addItem(wand);
        player.sendMessage(ChatColor.GREEN + "Жезл бомб выдан. ПКМ, чтобы бросить бомбу.");
    }

    /** Точка, куда смотрит игрок, на заданном расстоянии (если препятствий нет — по максимальной дистанции). */
    private Location lookTarget(Player player, double maxDistance) {
        Block block = player.getTargetBlockExact((int) maxDistance);
        if (block != null) {
            return block.getLocation().add(0.5, 1, 0.5);
        }
        return player.getEyeLocation().add(player.getEyeLocation().getDirection().multiply(maxDistance));
    }

    // ---------- жезл бомб ----------

    @EventHandler
    public void onBombWandUse(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        Player player = event.getPlayer();
        if (item == null || item.getItemMeta() == null || !BOMB_NAME.equals(item.getItemMeta().getDisplayName())) {
            return;
        }
        if (!player.hasPermission("adminmod.use")) {
            return;
        }
        event.setCancelled(true);
        Snowball bomb = player.launchProjectile(Snowball.class);
        bomb.setVelocity(player.getEyeLocation().getDirection().multiply(1.6));
        bomb.setMetadata("adminmod_bomb", new org.bukkit.metadata.FixedMetadataValue(this, true));
    }

    @EventHandler
    public void onBombHit(ProjectileHitEvent event) {
        if (!(event.getEntity() instanceof Snowball bomb) || !bomb.hasMetadata("adminmod_bomb")) {
            return;
        }
        Location loc = bomb.getLocation();
        loc.getWorld().createExplosion(loc, 3.0f, false, true);
    }

    // ---------- метеоритный дождь ----------

    static Location lookTargetStatic(Player player, double maxDistance) {
        Block block = player.getTargetBlockExact((int) maxDistance);
        if (block != null) {
            return block.getLocation().add(0.5, 1, 0.5);
        }
        return player.getEyeLocation().add(player.getEyeLocation().getDirection().multiply(maxDistance));
    }
}
